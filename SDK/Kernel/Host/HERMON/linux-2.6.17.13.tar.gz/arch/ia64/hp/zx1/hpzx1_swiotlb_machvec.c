#define MACHVEC_PLATFORM_NAME		hpzx1_swiotlb
#define MACHVEC_PLATFORM_HEADER		<asm/machvec_hpzx1_swiotlb.h>
#include <asm/machvec_init.h>
