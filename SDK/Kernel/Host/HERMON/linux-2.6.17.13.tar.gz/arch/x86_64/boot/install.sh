#!/bin/sh
. $srctree/arch/i386/boot/install.sh
