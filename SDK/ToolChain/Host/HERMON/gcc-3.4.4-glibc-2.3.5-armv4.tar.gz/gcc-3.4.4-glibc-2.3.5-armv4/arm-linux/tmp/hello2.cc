#include <iostream>
int main() { std::cout << "Hello, c++!\n"; return 0; }
