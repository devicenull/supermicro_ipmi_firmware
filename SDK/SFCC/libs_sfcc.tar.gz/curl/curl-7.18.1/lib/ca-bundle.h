/* This file is generated automatically */
#undef CURL_CA_BUNDLE /* unknown default path */
#undef CURL_CA_PATH /* unknown default path */
