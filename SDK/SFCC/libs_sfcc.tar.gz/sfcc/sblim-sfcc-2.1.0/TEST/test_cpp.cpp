
#include <stdlib.h>

#include <cmci.h>
#include <native.h>
#include <cmcimacs.h>
#include "show.h"

int
main(int argc, char** argv)
{
    exit(0);
}
