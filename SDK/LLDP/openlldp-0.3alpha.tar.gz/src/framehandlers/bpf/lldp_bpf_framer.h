#ifdef BPF_FRAMER
#ifndef __BPF_FRAMER_H__
#define __BPF_FRAMER_H__

static int _getmac(char *dest, char *ifname);
static int _getip(char *dest, char *ifname);

#endif /* __BPF_FRAMER_H__ */
#endif /* BPF_FRAMER */
