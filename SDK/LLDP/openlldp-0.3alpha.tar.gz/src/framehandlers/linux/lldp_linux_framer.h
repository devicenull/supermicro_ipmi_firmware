#ifndef __LLDP_LINUX_FRAMER_H__
#define __LLDP_LINUX_FRAMER_H__

int socketInitializeLLDP();
void socketCleanupLLDP();

#endif /* __LLDP_LINUX_FRAMER_H__ */
