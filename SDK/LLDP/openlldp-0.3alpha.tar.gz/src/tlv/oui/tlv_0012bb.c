/** @file 0012bb.c
    Authors: Terry Simons (terry.simons@gmail.com)
 */
