/** @file 000ecf.h
   Authors: Terry Simons (terry.simons@gmail.com)
*/
#ifndef LLDP_TLV_000ECF_H
#define LLDP_TLV_000ECF_H

#endif /* LLDP_TLV_000ECF_H */
