/* The code in this file code is Public Domain */

unsigned short query_con_codepage(void);
