/*
 * version file for ntpd
 */
#include <config.h>
const char * Version = "ntpd 4.2.4p4@1.1520 Thu Dec 25 06:19:13 UTC 2008 (54)";
