/*
 * version file for ntpdate
 */
#include <config.h>
const char * Version = "ntpdate 4.2.4p4@1.1520 Thu Dec 25 06:19:15 UTC 2008 (78)";
