/*
 * version file for ntpdc
 */
#include <config.h>
const char * Version = "ntpdc 4.2.4p4@1.1520 Wed Dec 24 02:35:05 UTC 2008 (47)";
