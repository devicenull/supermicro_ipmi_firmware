/*
 * version file for ntpq
 */
#include <config.h>
const char * Version = "ntpq 4.2.4p4@1.1520 Wed Dec 24 02:35:08 UTC 2008 (46)";
