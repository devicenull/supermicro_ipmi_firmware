#include "ntp_types.h"

extern	void	getstartup	P((int, char **));
extern	void	getCmdOpts	P((int, char **));
