#ifndef __ntp_proto_h
#define __ntp_proto_h

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#define NTP_MAXFREQ	500e-6
 
#endif /* __ntp_proto_h */
